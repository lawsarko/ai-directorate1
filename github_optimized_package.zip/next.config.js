module.exports = {
  output: 'standalone',
  images: {
    unoptimized: true,
  },
  swcMinify: true,
}
